package com.cmov.bomberman.standAlone;

public interface IMoveableRobot {

	void RobotMovedAtLogicalLayer();
}
