package com.cmov.bomberman.standAlone;

public interface IExplodable {

	void Exploaded(boolean isPlayerDead);
}
