package com.cmov.bomberman.wifidirect;

public interface IExplodable {

	void Exploaded(boolean isPlayerDead , String bombexlodemsg);
}
