package com.cmov.bomberman.wifidirect;

public interface IMoveableRobot {

	void RobotMovedAtLogicalLayer(String Robotmovementbuffer);
}
