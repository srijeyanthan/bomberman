/** Automatically generated file. DO NOT MODIFY */
package com.cmov.bomberman;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}