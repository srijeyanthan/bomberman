package com.cmov.bomberman.server;

public interface IMoveableRobot {

	void RobotMovedAtLogicalLayer(String Robotmovementbuffer);
}
