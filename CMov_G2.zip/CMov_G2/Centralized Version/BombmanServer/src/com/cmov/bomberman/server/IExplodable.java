package com.cmov.bomberman.server;

public interface IExplodable {

	void Exploaded(boolean isPlayerDead , String bombexlodemsg);
}
